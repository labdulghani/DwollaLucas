
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.*;
import org.json.simple.JSONObject;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.*;
public class AWSDwolla {
	

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws IOException {
		
		//S3 Variables
		String s3Path = null;
		String bucketName = null;
		String keyName = null;
		
		//Regular Expression for IPs
		String IPADDRESS_PATTERN = 
				"(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)";
		
		Pattern pattern = Pattern.compile(IPADDRESS_PATTERN);
		Matcher matcher;
		String match = null;
		
		//store results
		ArrayList<String> ipAddresses = new ArrayList<String>();
		int[] rejectCounts = new int[10];
		int rejectIndex = -1;
		
		//get file name
		Scanner scraper = new Scanner(System.in);
		System.out.print("Input filename to be scanned:");
		String filename = scraper.nextLine();
		
		//get S3 Location, separate bucket name and key name
		System.out.print("Input S3 URL for upload:");
		s3Path = scraper.nextLine();
		AmazonS3URI s3URL = new AmazonS3URI(s3Path);
		bucketName=s3URL.getBucket();
		keyName=s3URL.getKey();	
		
		//read from file
		FileReader reader = new FileReader(filename);
		BufferedReader bufferedReader = new BufferedReader(reader);
		String line = null;
		
		while ((line = bufferedReader.readLine()) != null ){
			match = null;
			if (line.contains("REJECT")){
					matcher = pattern.matcher(line);
						if (matcher.find()){
							match = matcher.group();		
						}
						if (!ipAddresses.contains(match)){
							ipAddresses.add(match);
							rejectIndex = ipAddresses.indexOf(match);
							rejectCounts[rejectIndex] = rejectCounts[rejectIndex]+1;
		
						}		
						else{
							rejectIndex = ipAddresses.indexOf(match);
							rejectCounts[rejectIndex] = rejectCounts[rejectIndex]+1;
						}
			}		
		}
		
		//create JSON
		JSONObject JSON = new JSONObject();
		for (int i=0; i<ipAddresses.size();i++){
			JSON.put(ipAddresses.get(i),rejectCounts[i]);	
		}
		
		//write JSON to file
		File uploadFile = new File("C:\\Users\\Public\\Documents","Dwolla_IP_Rejects.json");
		FileWriter file = new FileWriter(uploadFile);
		file.write(JSON.toJSONString());
		
		// Upload to S3
		AmazonS3 s3client = new AmazonS3Client(new ProfileCredentialsProvider());
		try {
			System.out.println("Uploading a new object to S3 from file- "+uploadFile);
			s3client.putObject(bucketName,keyName,uploadFile);
		} catch (AmazonServiceException ase){
            System.out.println("Caught an AmazonServiceException, which " +
            		"means your request made it " +
                    "to Amazon S3, but was rejected with an error response" +
                    " for some reason.");
            System.out.println("Error Message:    " + ase.getMessage());
            System.out.println("HTTP Status Code: " + ase.getStatusCode());
            System.out.println("AWS Error Code:   " + ase.getErrorCode());
            System.out.println("Error Type:       " + ase.getErrorType());
            System.out.println("Request ID:       " + ase.getRequestId());
        } catch (AmazonClientException ace) {
            System.out.println("Caught an AmazonClientException, which " +
            		"means the client encountered " +
                    "an internal error while trying to " +
                    "communicate with S3, " +
                    "such as not being able to access the network.");
            System.out.println("Error Message: " + ace.getMessage());
        }

		scraper.close();
		bufferedReader.close();
		file.close();
		//uploadFile.delete();
	}
	
}
